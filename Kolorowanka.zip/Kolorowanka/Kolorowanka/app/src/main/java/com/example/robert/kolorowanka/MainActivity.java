package com.example.robert.kolorowanka;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public Button lv1Button, lv2Button, lv3Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.lv1Button:
                Intent go1 = new Intent(MainActivity.this, Banan.class);
                startActivity(go1);
                break;
            case R.id.lv2Button:
                Intent go2 = new Intent(MainActivity.this, Arbuz1.class);
                startActivity(go2);
                break;
            case R.id.lv3Button:
                Intent go3 = new Intent(MainActivity.this, Slon1.class);
                startActivity(go3);
                break;
            case R.id.instrButton:
                Intent goInstr = new Intent(MainActivity.this, Instr.class);
                startActivity(goInstr);
                break;
        }
    }
}

