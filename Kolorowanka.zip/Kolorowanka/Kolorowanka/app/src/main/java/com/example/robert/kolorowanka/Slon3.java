package com.example.robert.kolorowanka;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Slon3 extends GameLv3 implements View.OnClickListener{


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_layout);


        brazButton = findViewById(R.id.brazButton);
        pomaranczButton = findViewById(R.id.pomaranczButton);
        czerwButton = findViewById(R.id.czerwButton);
        zoltyButton = findViewById(R.id.zoltyButton);
        zielButton = findViewById(R.id.zielButton);
        brazButton.setOnClickListener(this);
        pomaranczButton.setOnClickListener(this);
        czerwButton.setOnClickListener(this);
        zielButton.setOnClickListener(this);
        zoltyButton.setOnClickListener(this);

        display = findViewById(R.id.imgView);
        display.setImageResource(R.drawable.slon3);
        TextView tekstObrazka = findViewById(R.id.textView);
        tekstObrazka.setText("Słonecznik");
    }

    public void onClick(View v) {

        Toast t1 = Toast.makeText(getApplicationContext(), "SPRÓBUJ PONOWNIE", Toast.LENGTH_SHORT);
        Toast t2 = Toast.makeText(getApplicationContext(), "GRATULACJE", Toast.LENGTH_SHORT);
        Toast t3 = Toast.makeText(getApplicationContext(), "KONIEC", Toast.LENGTH_SHORT);

        switch (v.getId()) {
            case R.id.nextButton:
                Intent go1 = new Intent(Slon3.this, MainActivity.class);
                t3.show();
                startActivity(go1);
                break;
            case R.id.backButton:
                Intent goBack = new Intent(Slon3.this, MainActivity.class);
                startActivity(goBack);
                break;
            case R.id.zoltyButton:
                display.setImageResource(R.drawable.slon_kolor);
                t2.show();
                break;
            case R.id.zielButton:
                display.setImageResource(R.drawable.slon3);
                t1.show();
                break;
            case R.id.brazButton:
                display.setImageResource(R.drawable.slon3);
                t1.show();
                break;
            case R.id.pomaranczButton:
                display.setImageResource(R.drawable.slon3);
                t1.show();
                break;
            case R.id.czerwButton:
                display.setImageResource(R.drawable.slon3);
                t1.show();
                break;
        }
    }
}