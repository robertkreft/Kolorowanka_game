package com.example.robert.kolorowanka;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class GameLv1 extends MainActivity implements View.OnClickListener {
    public Button backButton, brazButton, pomaranczButton, czerwButton, zoltyButton, zielButton;
    ImageView display;

    public ImageView imgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_layout);


        brazButton = findViewById(R.id.brazButton);
        pomaranczButton = findViewById(R.id.pomaranczButton);
        czerwButton = findViewById(R.id.czerwButton);
        zoltyButton = findViewById(R.id.zoltyButton);
        zielButton = findViewById(R.id.zielButton);
        brazButton.setOnClickListener(this);
        pomaranczButton.setOnClickListener(this);
        czerwButton.setOnClickListener(this);
        zielButton.setOnClickListener(this);
        zoltyButton.setOnClickListener(this);

        display = findViewById(R.id.imgView);
        ImageView img1 = findViewById(R.id.imgView);
        img1.setOnClickListener(this);
    }

    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.nextButton:
                Intent goL1 = new Intent(GameLv1.this, Banan.class);
                startActivity(goL1);
                break;
            case R.id.backButton:
                Intent goBack = new Intent(GameLv1.this, MainActivity.class);
                startActivity(goBack);
                break;

        }
    }
}




