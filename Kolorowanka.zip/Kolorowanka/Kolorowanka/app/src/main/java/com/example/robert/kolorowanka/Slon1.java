package com.example.robert.kolorowanka;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Slon1 extends GameLv3 implements View.OnClickListener{


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_layout);


        brazButton = findViewById(R.id.brazButton);
        pomaranczButton = findViewById(R.id.pomaranczButton);
        czerwButton = findViewById(R.id.czerwButton);
        zoltyButton = findViewById(R.id.zoltyButton);
        zielButton = findViewById(R.id.zielButton);
        brazButton.setOnClickListener(this);
        pomaranczButton.setOnClickListener(this);
        czerwButton.setOnClickListener(this);
        zielButton.setOnClickListener(this);
        zoltyButton.setOnClickListener(this);

        display = findViewById(R.id.imgView);
        display.setImageResource(R.drawable.slon1);
        TextView tekstObrazka = findViewById(R.id.textView);
        tekstObrazka.setText("Słonecznik");

        final MediaPlayer sound3 = MediaPlayer.create(this, R.raw.slonecznik);
        sound3.start();
    }

    public void onClick(View v) {

        Toast t1 = Toast.makeText(getApplicationContext(), "SPRÓBUJ PONOWNIE", Toast.LENGTH_SHORT);

        switch (v.getId()) {
            case R.id.nextButton:
                Intent go1 = new Intent(Slon1.this, Slon2.class);
                startActivity(go1);
                break;
            case R.id.backButton:
                Intent goBack = new Intent(Slon1.this, MainActivity.class);
                startActivity(goBack);
                break;
            case R.id.zoltyButton:
                display.setImageResource(R.drawable.slon1);
                t1.show();
                break;
            case R.id.zielButton:
                display.setImageResource(R.drawable.slon1);
                t1.show();
                break;
            case R.id.brazButton:
                Intent go2 = new Intent(Slon1.this, Slon2.class);
                startActivity(go2);
                break;
            case R.id.pomaranczButton:
                display.setImageResource(R.drawable.slon1);
                t1.show();
                break;
            case R.id.czerwButton:
                display.setImageResource(R.drawable.slon1);
                t1.show();
                break;
        }
    }
}