package com.example.robert.kolorowanka;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Instr extends MainActivity implements View.OnClickListener {

    public Button backButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.instrukcja);
    }

    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.backButton:
                Intent goBack = new Intent(Instr.this, MainActivity.class);
                startActivity(goBack);
                break;

        }
    }
}
