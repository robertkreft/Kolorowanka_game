package com.example.robert.kolorowanka;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Dynia extends GameLv1 {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_layout);


        brazButton = findViewById(R.id.brazButton);
        pomaranczButton = findViewById(R.id.pomaranczButton);
        czerwButton = findViewById(R.id.czerwButton);
        zoltyButton = findViewById(R.id.zoltyButton);
        zielButton = findViewById(R.id.zielButton);
        brazButton.setOnClickListener(this);
        pomaranczButton.setOnClickListener(this);
        czerwButton.setOnClickListener(this);
        zielButton.setOnClickListener(this);
        zoltyButton.setOnClickListener(this);

        display = findViewById(R.id.imgView);
        ImageView img1 = findViewById(R.id.imgView);
        img1.setOnClickListener(this);

        display.setImageResource(R.drawable.dynia);
        TextView tekstObrazka = findViewById(R.id.textView);
        tekstObrazka.setText("Dynia");

        final MediaPlayer sound = MediaPlayer.create(this, R.raw.dynia);
        sound.start();
    }

    public void onClick(View v) {

        Toast t1 = Toast.makeText(getApplicationContext(), "SPRÓBUJ PONOWNIE", Toast.LENGTH_SHORT);
        Toast t2 = Toast.makeText(getApplicationContext(), "GRATULACJE", Toast.LENGTH_SHORT);

        switch (v.getId()) {
            case R.id.nextButton:
                Intent go1 = new Intent(Dynia.this, Kaktus.class);
                startActivity(go1);
                break;
            case R.id.backButton:
                Intent goBack = new Intent(Dynia.this, MainActivity.class);
                startActivity(goBack);
                break;
            case R.id.zoltyButton:
                display.setImageResource(R.drawable.dynia);
                t1.show();
                break;
            case R.id.zielButton:
                display.setImageResource(R.drawable.dynia);
                t1.show();
                break;
            case R.id.brazButton:
                display.setImageResource(R.drawable.dynia);
                t1.show();
                break;
            case R.id.pomaranczButton:
                display.setImageResource(R.drawable.dynia_kolor);
                t2.show();
                break;
            case R.id.czerwButton:
                display.setImageResource(R.drawable.dynia);
                t1.show();
                break;
        }
    }
}
